package com.example.martinzamarski.moviedatabasekotlin.data.database

import android.arch.lifecycle.LiveData
import android.arch.persistence.room.Dao
import android.arch.persistence.room.Insert
import android.arch.persistence.room.OnConflictStrategy
import android.arch.persistence.room.Query
import com.example.martinzamarski.moviedatabasekotlin.model.Movie

@Dao
interface MovieDao {

    @Query("SELECT * FROM movie")
    fun loadAllMovie(): LiveData<List<Movie>>

    @Query("DELETE FROM movie")
    fun deleteMovie()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertMovies(movies: List<Movie>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertMovie(movie: Movie)
}