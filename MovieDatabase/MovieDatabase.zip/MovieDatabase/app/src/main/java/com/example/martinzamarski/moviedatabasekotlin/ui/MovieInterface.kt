package com.example.martinzamarski.moviedatabasekotlin.ui

import com.example.martinzamarski.moviedatabasekotlin.model.Movie

interface MovieInterface {
    fun onClick(movie: Movie)
}