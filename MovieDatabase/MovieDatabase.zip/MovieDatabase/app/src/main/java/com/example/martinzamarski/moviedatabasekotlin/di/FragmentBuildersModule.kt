package com.example.martinzamarski.moviedatabasekotlin.di

import com.example.martinzamarski.moviedatabasekotlin.ui.DetailActivity.DetailFragment
import com.example.martinzamarski.moviedatabasekotlin.ui.MoviesList.MoviesListFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Suppress("unused")
@Module
abstract class FragmentBuildersModule {
    @ContributesAndroidInjector
    abstract fun contributeMainFragment(): MoviesListFragment

    @ContributesAndroidInjector
    abstract fun contributeDetailFragment(): DetailFragment

}
