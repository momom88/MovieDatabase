package com.example.martinzamarski.moviedatabasekotlin.ui.DetailActivity

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.ViewModel
import com.example.martinzamarski.moviedatabasekotlin.data.MovieRepository
import com.example.martinzamarski.moviedatabasekotlin.model.Reviews
import javax.inject.Inject


class DetailViewModel @Inject constructor(private val movieRepository: MovieRepository) : ViewModel() {

    private lateinit var mReviews: LiveData<List<Reviews>>

//        the call to repository method to display the current data according to the user's request
    fun getReviews(id: Int): LiveData<List<Reviews>> {
        mReviews = movieRepository.getReviews(id)
        return mReviews
    }
}