package com.example.martinzamarski.moviedatabasekotlin.di

/**
 * Marks an activity / fragment injectable.
 */
interface Injectable